
public enum State {
	CLEAN, DIRTY, HALFDIRTY
}


